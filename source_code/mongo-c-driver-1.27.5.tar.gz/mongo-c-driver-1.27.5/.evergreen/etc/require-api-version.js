db.adminCommand({ "setParameter": 1, "requireApiVersion": 1 });
